<!--STEALTH MODE-->


<div id="content">
	<article id="about" class="page show">
		<h1 class="soon"><?php echo __('Check Back Soon!');?></h1> 
		<?php echo mh_about();?>		
	</article>
</div> 