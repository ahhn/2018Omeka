/*
 * AngularJS wrapper for jQuery mmenu
 * Include this file after including the jquery.mmenu plugin for default AngularJS route support.
 */
!function(e){var l="mmenu";e[l].defaults.onClick.close=!0,e[l].defaults.onClick.preventDefault=!1,e[l].defaults.onClick.setSelected=!0}(jQuery);